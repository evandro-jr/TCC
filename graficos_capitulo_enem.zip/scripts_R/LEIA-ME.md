# Gráficos da ACM do capítulo: como reproduzir

Estes scripts refazem a Análise de Correspondência Múltipla do TCC sobre os microdados do ENEM 2019 e desenham os três gráficos do capítulo no padrão do Modelo 1 do livro: 16 cm de largura, PNG a 360 dpi e PDF vetorial, fonte Times em corpo 10, com os rótulos tirados do dicionário de dados.

## Preparação

1. Coloque nesta pasta o arquivo `microdados_enem_2019.zip`, baixado do INEP. O script extrai sozinho só o CSV necessário, com cerca de 3,2 GB, para uma pasta temporária.
2. Instale os pacotes: `install.packages(c("data.table", "caret", "FactoMineR", "ggplot2", "ggrepel", "ragg", "scales"))`.
3. No RStudio, defina esta pasta como diretório de trabalho (Session > Set Working Directory > To Source File Location).

## Execução, nesta ordem

| Script | O que faz | Saída |
| --- | --- | --- |
| `reproducao.R` | tratamento igual ao do TCC (seleção de colunas, presença em Matemática, retirada de ausentes, quintis das notas) e partição de teste de 2% com `set.seed(1234)` | `db_tratada.rds`, `teste.rds` |
| `coordenadas.R` | ACM de cada bloco e razões de correlação (η²) das variáveis nas dimensões 1 e 2 | `coordenadas_eta2.csv` |
| `graficos.R` | desenha os três gráficos; no Gráfico 3 os rótulos seguem as posições de `layout_g3.csv` | pasta `graficos/` com G1, G2 e G3 em PNG e PDF |

Os arquivos `coordenadas_eta2.csv` e `layout_g3.csv` já vêm prontos. Para só redesenhar os gráficos, basta rodar `graficos.R`.

## Observações

- O pacote `dvmisc`, usado no TCC para os quintis, saiu do CRAN. A função `quant_groups` foi reescrita dentro do `reproducao.R` com o mesmo corte por quantis, e os limites conferem com a tabela do capítulo (421, 467, 524, 606 e 986).
- A base tratada tem 2.120.104 linhas, e as coordenadas batem com as dos gráficos originais do TCC. Os percentuais de inércia impressos nos eixos dos gráficos originais não correspondiam aos pontos desenhados. Os valores corretos, que aparecem nos gráficos novos, são: Bloco 1, 3,18% e 1,63%; Bloco 2, 16,66% e 9,14%; Bloco 3, 6,63% e 3,04%.
