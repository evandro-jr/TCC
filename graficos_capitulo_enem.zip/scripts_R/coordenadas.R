# Variable coordinates (correlation ratio eta^2 on dims 1 and 2) for the three blocks,
# on the 2% test partition, saved for plotting and for comparison with the original figures.
library(data.table)
library(FactoMineR)

base_dir <- "."  # pasta com os scripts e o microdados_enem_2019.zip
teste <- readRDS(file.path(base_dir, "teste.rds"))

blocos <- list(
  B1 = c("NU_IDADE", "TP_SEXO", "TP_COR_RACA", "SG_UF_NASCIMENTO", "TP_ST_CONCLUSAO",
         "TP_ESCOLA", "TP_ENSINO", "nota_matematica"),
  B2 = c("nota_matematica", "nota_natureza", "nota_humanas", "nota_linguagem", "nota_redacao"),
  B3 = c(sprintf("Q%03d", 1:25), "nota_matematica")
)

out <- rbindlist(lapply(names(blocos), function(b) {
  x <- as.data.frame(lapply(teste[, blocos[[b]], with = FALSE], as.factor))
  res <- MCA(x, ncp = 2, graph = FALSE)
  data.table(bloco = b, variavel = rownames(res$var$eta2),
             dim1 = res$var$eta2[, 1], dim2 = res$var$eta2[, 2],
             pct1 = res$eig[1, 2], pct2 = res$eig[2, 2])
}))
fwrite(out, file.path(base_dir, "coordenadas_eta2.csv"))
print(out[, .(bloco, variavel, dim1 = round(dim1, 3), dim2 = round(dim2, 3))])
print(unique(out[, .(bloco, pct1 = round(pct1, 2), pct2 = round(pct2, 2))]))
