# Reproduce the MCA of the ENEM 2019 thesis (repository evandro-jr/TCC) and check which
# configuration yields the inertia percentages printed on the original figures:
#   Block 1: Dim 1 = 2.58%, Dim 2 = 1.33%
#   Block 2: Dim 1 = 15.67%, Dim 2 = 5.17%
#   Block 3: Dim 1 = 6.58%, Dim 2 = 3.00%

library(data.table)
# dvmisc::quant_groups (package archived on CRAN): quintile cut, right-closed, lowest included
quant_groups <- function(x, groups = 5) {
  q <- quantile(x, probs = seq(0, 1, 1 / groups), na.rm = TRUE)
  cut(x, breaks = q, include.lowest = TRUE)
}
library(caret)
library(FactoMineR)

base_dir <- "."  # pasta com os scripts e o microdados_enem_2019.zip
zip_path <- file.path(base_dir, "microdados_enem_2019.zip")
rds_path <- file.path(base_dir, "db_tratada.rds")

cols <- c("NU_ANO", "NU_IDADE", "TP_SEXO", "TP_COR_RACA", "SG_UF_NASCIMENTO", "TP_ST_CONCLUSAO",
          "TP_ESCOLA", "TP_ENSINO", "TP_PRESENCA_MT", "NU_NOTA_CN", "NU_NOTA_CH", "NU_NOTA_LC",
          "NU_NOTA_MT", "NU_NOTA_REDACAO", sprintf("Q%03d", 1:25))

if (!file.exists(rds_path)) {
  # tratamento_dados.R, same selection, filter and na.omit
  # extract only the microdata CSV (about 3.2 GB) to a temporary folder; works on Windows, Linux and macOS
  csv_path <- utils::unzip(zip_path, files = "DADOS/MICRODADOS_ENEM_2019.csv", exdir = tempdir())
  db1 <- fread(csv_path, select = cols, sep = ";", encoding = "Latin-1")
  cat("linhas brutas:", nrow(db1), "\n")
  db1 <- db1[TP_PRESENCA_MT == 1]
  db1 <- na.omit(db1)
  db1[, NU_ANO := NULL]
  db1[, nota_matematica := quant_groups(NU_NOTA_MT, 5)]
  db1[, nota_natureza := quant_groups(NU_NOTA_CN, 5)]
  db1[, nota_humanas := quant_groups(NU_NOTA_CH, 5)]
  db1[, nota_linguagem := quant_groups(NU_NOTA_LC, 5)]
  db1[, nota_redacao := quant_groups(NU_NOTA_REDACAO, 5)]
  saveRDS(db1, rds_path)
} else {
  db1 <- readRDS(rds_path)
}
cat("base tratada:", nrow(db1), "linhas x", ncol(db1), "colunas\n")
print(levels(db1$nota_matematica))

# data_partition.R: 2% test sample used for the MCA
set.seed(1234)
intrain <- createDataPartition(db1$NU_NOTA_MT, p = 0.98, list = FALSE)
teste <- db1[-intrain[, 1]]
cat("amostra de teste:", nrow(teste), "\n")
saveRDS(teste, file.path(base_dir, "teste.rds"))

b1 <- c("NU_IDADE", "TP_SEXO", "TP_COR_RACA", "SG_UF_NASCIMENTO", "TP_ST_CONCLUSAO",
        "TP_ESCOLA", "TP_ENSINO", "nota_matematica")
b2 <- c("nota_matematica", "nota_natureza", "nota_humanas", "nota_linguagem", "nota_redacao")
b3_repo <- c(sprintf("Q%03d", 1:25), b2)
b3_fig <- c(sprintf("Q%03d", 1:25), "nota_matematica")

pct <- function(dt, vars) {
  x <- as.data.frame(lapply(dt[, ..vars], as.factor))
  res <- MCA(x, ncp = 2, graph = FALSE)
  round(res$eig[1:2, 2], 2)
}

for (nome in c("teste", "completa")) {
  dt <- if (nome == "teste") teste else db1
  if (nome == "completa" && nrow(dt) > 3e5) next
  cat("\n==", nome, "==\n")
  cat("B1:", pct(dt, b1), "\n")
  cat("B2:", pct(dt, b2), "\n")
  cat("B3 repo (Q + 5 notas):", pct(dt, b3_repo), "\n")
  cat("B3 fig (Q + nota_matematica):", pct(dt, b3_fig), "\n")
}
