# MCA variable maps (correlation ratio eta^2) for the three blocks of the ENEM 2019 chapter.
# Book template: 16 cm wide, 360 dpi PNG plus vector PDF, Times, 10 pt inside the figure,
# no internal title (the caption is set in LaTeX), decimal comma, groups told apart by
# colour and shape so the figure survives greyscale printing.
library(data.table)
library(ggplot2)
library(ggrepel)
library(ragg)

base_dir <- "."  # pasta com os scripts e o microdados_enem_2019.zip
out_dir <- file.path(base_dir, "graficos")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
coords <- fread(file.path(base_dir, "coordenadas_eta2.csv"))

FONTE <- "Times New Roman"
PT <- 10
TXT <- PT / .pt

rotulos <- c(
  NU_IDADE = "Idade", TP_SEXO = "Sexo", TP_COR_RACA = "Cor/raça",
  SG_UF_NASCIMENTO = "UF de nascimento", TP_ST_CONCLUSAO = "Situação de conclusão do ensino médio",
  TP_ESCOLA = "Tipo de escola do ensino médio", TP_ENSINO = "Tipo de instituição de ensino",
  nota_matematica = "Nota de Matemática", nota_natureza = "Ciências da Natureza",
  nota_humanas = "Ciências Humanas", nota_linguagem = "Linguagens e Códigos", nota_redacao = "Redação",
  Q001 = "Escolaridade do pai", Q002 = "Escolaridade da mãe", Q003 = "Ocupação do pai",
  Q004 = "Ocupação da mãe", Q005 = "Pessoas na residência", Q006 = "Renda familiar",
  Q007 = "Empregado(a) doméstico(a)", Q008 = "Banheiros", Q009 = "Quartos", Q010 = "Carro",
  Q011 = "Motocicleta", Q012 = "Geladeira", Q013 = "Freezer", Q014 = "Máquina de lavar roupa",
  Q015 = "Máquina de secar roupa", Q016 = "Micro-ondas", Q017 = "Máquina de lavar louça",
  Q018 = "Aspirador de pó", Q019 = "Televisão em cores", Q020 = "Aparelho de DVD",
  Q021 = "TV por assinatura", Q022 = "Telefone celular", Q023 = "Telefone fixo",
  Q024 = "Computador", Q025 = "Acesso à internet"
)

grupos <- list(
  B1 = c(NU_IDADE = "Perfil do participante", TP_SEXO = "Perfil do participante",
         TP_COR_RACA = "Perfil do participante", SG_UF_NASCIMENTO = "Perfil do participante",
         TP_ST_CONCLUSAO = "Trajetória escolar", TP_ESCOLA = "Trajetória escolar",
         TP_ENSINO = "Trajetória escolar"),
  B2 = c(nota_natureza = "Demais componentes", nota_humanas = "Demais componentes",
         nota_linguagem = "Demais componentes", nota_redacao = "Demais componentes"),
  B3 = c(setNames(rep("Responsáveis", 4), sprintf("Q%03d", 1:4)),
         setNames(rep("Renda e domicílio", 5), sprintf("Q%03d", 5:9)),
         setNames(rep("Veículos e eletrodomésticos", 9), sprintf("Q%03d", 10:18)),
         setNames(rep("Mídia e comunicação", 7), sprintf("Q%03d", 19:25)))
)

# Palette with distinct lightness (readable in greyscale), paired with distinct shapes.
paleta <- c("Perfil do participante" = "#1F5A85", "Trajetória escolar" = "#D08C2E",
            "Demais componentes" = "#1F5A85",
            "Responsáveis" = "#1F5A85", "Renda e domicílio" = "#6FA8C9",
            "Veículos e eletrodomésticos" = "#D08C2E", "Mídia e comunicação" = "#7A7A7A",
            "Nota de Matemática" = "#B3261E")
formas <- c("Perfil do participante" = 21, "Trajetória escolar" = 24, "Demais componentes" = 21,
            "Responsáveis" = 21, "Renda e domicílio" = 22, "Veículos e eletrodomésticos" = 24,
            "Mídia e comunicação" = 25, "Nota de Matemática" = 23)

virgula <- function(x) formatC(x, format = "f", digits = 2, decimal.mark = ",")

grafico <- function(bloco_id, arquivo, altura_cm, com_codigo = FALSE, forca = 1.2,
                    x_max = 1, y_min = -0.02, legenda = TRUE, linhas_legenda = 1,
                    nudges = list(), semente = 42, sufixo = "", x_min = -0.02,
                    layout = NULL) {
  d <- coords[coords$bloco == bloco_id]
  d[, grupo := fifelse(variavel == "nota_matematica", "Nota de Matemática",
                       unname(grupos[[bloco_id]][variavel]))]
  d[, rotulo := unname(rotulos[variavel])]
  if (com_codigo) d[grepl("^Q", variavel), rotulo := paste0(rotulo, " (", variavel, ")")]
  d[, destaque := variavel == "nota_matematica"]
  d[, `:=`(nx = 0, ny = 0)]
  for (v in names(nudges)) d[variavel == v, `:=`(nx = nudges[[v]][1], ny = nudges[[v]][2])]
  niveis <- c(setdiff(unique(d$grupo), "Nota de Matemática"), "Nota de Matemática")
  d[, grupo := factor(grupo, levels = niveis)]
  pct1 <- sub(".", ",", sprintf("%.2f", d$pct1[1]), fixed = TRUE)
  pct2 <- sub(".", ",", sprintf("%.2f", d$pct2[1]), fixed = TRUE)
  lim_x <- c(x_min, x_max)
  lim_y <- c(y_min, max(d$dim2) * 1.12 + 0.02)

  if (is.null(layout)) {
    rotulos_camada <- list(
    geom_text_repel(aes(label = rotulo, colour = grupo, fontface = ifelse(destaque, "bold", "plain")),
                    family = FONTE, size = TXT, seed = semente, force = forca, force_pull = 0.5,
                    box.padding = 0.45, point.padding = 0.3, min.segment.length = 0.1,
                    max.iter = 200000, max.time = 30, xlim = lim_x, ylim = lim_y,
                    segment.colour = "grey60", segment.size = 0.25, max.overlaps = Inf,
                    nudge_x = d$nx, nudge_y = d$ny,
                    bg.colour = "white", bg.r = 0.18, point.size = ifelse(d$destaque, 3.8, 2.6),
                    show.legend = FALSE)
    )
  } else {
    # Hand placed labels: leader line from the point to (sx, sy), label anchored at (lx, ly).
    d <- merge(d, layout, by = "variavel", sort = FALSE)
    d[, liga := sqrt((sx - dim1)^2 + (sy - dim2)^2) > 0.014]
    rotulos_camada <- list(
      geom_segment(data = d[liga == TRUE], aes(x = dim1, y = dim2, xend = sx, yend = sy),
                   colour = "grey62", linewidth = 0.25),
      geom_label(aes(x = lx, y = ly, label = rotulo, colour = grupo, hjust = hj,
                     fontface = ifelse(destaque, "bold", "plain")),
                 family = FONTE, size = TXT, fill = scales::alpha("white", 0.9), border.colour = NA,
                 label.padding = unit(0.06, "lines"), show.legend = FALSE)
    )
  }
  p <- ggplot(d, aes(dim1, dim2)) +
    geom_hline(yintercept = 0, colour = "grey55", linewidth = 0.3, linetype = "22") +
    geom_vline(xintercept = 0, colour = "grey55", linewidth = 0.3, linetype = "22") +
    geom_point(aes(fill = grupo, shape = grupo, size = destaque), colour = "white", stroke = 0.45) +
    rotulos_camada +
    geom_point(aes(fill = grupo, shape = grupo, size = destaque), colour = "white", stroke = 0.45,
               show.legend = FALSE) +
    scale_fill_manual(values = paleta, name = NULL, drop = TRUE) +
    scale_colour_manual(values = sapply(paleta, function(x) colorspace_darken(x)), guide = "none") +
    scale_shape_manual(values = formas, name = NULL, drop = TRUE) +
    scale_size_manual(values = c(`FALSE` = 2.6, `TRUE` = 3.8), guide = "none") +
    scale_x_continuous(labels = virgula, breaks = seq(0, 1, 0.1), expand = expansion(0)) +
    scale_y_continuous(labels = virgula, breaks = seq(0, 1, 0.1), expand = expansion(0)) +
    coord_cartesian(xlim = lim_x, ylim = lim_y, clip = "off") +
    labs(x = paste0("Dimensão 1 (", pct1, "% da inércia)"),
         y = paste0("Dimensão 2 (", pct2, "% da inércia)")) +
    theme_minimal(base_family = FONTE, base_size = PT) +
    theme(panel.grid.minor = element_blank(),
          panel.grid.major = element_line(colour = "grey90", linewidth = 0.3),
          axis.title = element_text(size = PT, colour = "grey15"),
          axis.title.x = element_text(margin = margin(t = 6)),
          axis.title.y = element_text(margin = margin(r = 6)),
          axis.text = element_text(size = PT, colour = "grey30"),
          legend.position = "bottom", legend.text = element_text(size = PT),
          legend.key.size = unit(0.9, "lines"), legend.margin = margin(t = 0),
          plot.margin = margin(6, 16, 4, 4))
  p <- p + guides(fill = guide_legend(nrow = linhas_legenda, override.aes = list(size = 3.2)),
                  shape = guide_legend(nrow = linhas_legenda))
  if (!legenda) p <- p + theme(legend.position = "none")

  ggsave(file.path(out_dir, paste0(arquivo, sufixo, ".png")), p, device = agg_png,
         width = 16, height = altura_cm, units = "cm", dpi = 360, bg = "white")
  if (sufixo == "") ggsave(file.path(out_dir, paste0(arquivo, ".pdf")), p, device = cairo_pdf,
         width = 16, height = altura_cm, units = "cm", bg = "white")
  invisible(p)
}

# Darker text tone of each group colour, so labels stay legible on white.
colorspace_darken <- function(hex, f = 0.72) {
  rgb_ <- grDevices::col2rgb(hex)[, 1] * f
  grDevices::rgb(rgb_[1], rgb_[2], rgb_[3], maxColorValue = 255)
}

grafico("B1", "G1", altura_cm = 10.5, y_min = -0.05)
grafico("B2", "G2", altura_cm = 9, legenda = FALSE)
grafico("B3", "G3", altura_cm = 14.5, x_min = -0.015, x_max = 0.73, y_min = -0.125,
        linhas_legenda = 2, layout = fread(file.path(base_dir, "layout_g3.csv")))
cat("ok\n")
